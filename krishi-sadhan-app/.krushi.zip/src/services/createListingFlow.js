import { uploadImages } from "./cloudinaryService";
import { createListing } from "./listingService";

export async function createListingWithImages(formData, files) {
    try {
        // 1. Upload images
        const imageUrls = await uploadImages(files);

        // 2. Merge into listing data
        const listingData = {
            ...formData,
            images: imageUrls,
        };

        // 3. Save to Firestore
        const id = await createListing(listingData);

        return id;
    } catch (err) {
        console.error("Listing flow failed:", err);
        throw err;
    }
}



