import { db } from "./firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

export async function createListing(data) {
    try {
        const docRef = await addDoc(collection(db, "listings"), {
            ...data,
            createdAt: serverTimestamp(),
            isAvailable: true
        });

        return docRef.id;
    } catch (err) {
        console.error("Create listing error:", err);
        throw err;
    }
}